# d3pie - source code

This folder contains the d3pie source code.

* d3pie.js
* d3pie.min.js - the minified version of the source code (generally this is the one you'll want to use)


### For developers

If you're hacking on this script, you'll want to use grunt. The two source files in this folder are automatically
generated from the original source, found in [../d3pie-source](../d3pie-source).